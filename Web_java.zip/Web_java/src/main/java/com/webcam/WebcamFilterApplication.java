package com.webcam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebcamFilterApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebcamFilterApplication.class, args);
    }
} 